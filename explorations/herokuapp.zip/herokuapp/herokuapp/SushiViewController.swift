//
//  ViewController.swift
//  herokuapp
//
//  Created by Kauana dos Santos on 11/15/18.
//  Copyright © 2018 Kauana dos Santos. All rights reserved.
//

import UIKit
import Alamofire

// Download and parse JSON from the API and display it in a UITableView
private let kMyAppBaseURLString = "https://desolate-taiga-77264.herokuapp.com/sushi.json"
class SushiViewController: UIViewController, UITableViewDataSource {

    var sushi: [Any] = []

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sushi.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = "\(sushi[indexPath.row])"

        return cell
    }

    @IBOutlet weak var sushiTable: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        sushiTable.dataSource = self

        // https://grokswift.com/rest-with-alamofire-swiftyjson/
        Alamofire.request(kMyAppBaseURLString).responseJSON { response in
            print("Request: \(String(describing: response.request))")   // original url request
            print("Response: \(String(describing: response.response))") // http url response
            print("Result: \(response.result)")                         // response serialization result
            print("Value: \(String(describing: response.result.value))")

            if let json = response.result.value as? [String: Any] {
                print("JSON: \(json)") // serialized json response
                //self.sushi = [response.result.value!]
                self.sushi = json["sushi"] as! [String]
                self.sushiTable.reloadData()
            }

            if let data = response.data, let utf8Text = String(data: data, encoding: .utf8) {
                print("Data: \(utf8Text)") // original server data as UTF8 string
            }

            self.sushiTable.reloadData()
        }

    }


}

